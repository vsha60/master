#!C:\Ruby27-x64\bin\ruby –w
name = 'test_name'
Name = 'test_Name'
NAME = 'test_NAME'
puts name
puts Name
puts NAME