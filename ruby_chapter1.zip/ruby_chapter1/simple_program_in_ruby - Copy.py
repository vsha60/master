#!C:\Ruby27-x64\bin\ruby –w
puts "Hello world"