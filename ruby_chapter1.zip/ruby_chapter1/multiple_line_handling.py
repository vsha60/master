#!C:\Ruby27-x64\bin\ruby –w
print <<EOD
     Hi All, Thanks for joining us to learn ruby 
     Please do subscribe our channel and press the bell icon 
EOD