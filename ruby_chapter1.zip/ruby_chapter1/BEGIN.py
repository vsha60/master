#!C:\Ruby27-x64\bin\ruby –w
puts 'This is the first row'
BEGIN {
	puts 'Welcome to BEGIN statement'
}