#!C:\Ruby27-x64\bin\ruby –w
puts 'This is the first line'
END {
	puts 'This is the line in END statement'
}
BEGIN {
	puts 'This is the line in BEGIN statement'
}
